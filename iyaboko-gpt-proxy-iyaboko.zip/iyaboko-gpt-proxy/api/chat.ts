export const config = { runtime: "edge" };

const ALLOWED_ORIGINS = new Set([
  "https://www.iyaboko.org",
  "https://iyaboko.org",
]);

function cors(origin) {
  const allowOrigin = ALLOWED_ORIGINS.has(origin || "") ? origin : "*";
  return {
    "Access-Control-Allow-Origin": allowOrigin,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
  };
}

// Optional Upstash Redis for real rate limiting
async function checkRateLimit(ip) {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) {
    // very light, non-persistent guard (not strong)
    return true;
  }
  const key = `gptproxy:ratelimit:${ip}`;
  // 60 requests per 300 seconds (5 minutes)
  const lua = `
  local key = KEYS[1]
  local limit = tonumber(ARGV[1])
  local window = tonumber(ARGV[2])
  local current = redis.call("INCR", key)
  if current == 1 then
    redis.call("EXPIRE", key, window)
  end
  if current > limit then
    return 0
  else
    return 1
  end`;
  const body = {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ cmd: ["EVAL", lua, "1", key, "60", "300"] }),
  };
  try {
    const resp = await fetch(url, body);
    const data = await resp.json();
    return data && data.result === 1;
  } catch {
    return true; // fail open to avoid blocking legitimate traffic
  }
}

export default async function handler(request) {
  const origin = request.headers.get("origin") || "";
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: cors(origin) });
  }
  if (request.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: cors(origin) });
  }

  let payload;
  try {
    payload = await request.json();
  } catch {
    return new Response("Invalid JSON", { status: 400, headers: cors(origin) });
  }

  const { messages, system } = payload || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return new Response("`messages` array required", { status: 400, headers: cors(origin) });
  }

  // Basic size guard
  const totalChars = messages.map(m => (m.content || "")).join("").length;
  if (totalChars > 8000) {
    return new Response("Prompt too long", { status: 400, headers: cors(origin) });
  }

  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  const allowed = await checkRateLimit(ip);
  if (!allowed) {
    return new Response("Rate limit exceeded. Try again later.", { status: 429, headers: cors(origin) });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return new Response("Server misconfigured: missing OPENAI_API_KEY", { status: 500, headers: cors(origin) });
  }

  // Call OpenAI Responses API with SSE streaming
  const upstream = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      input: [
        ...(system ? [{ role: "system", content: system }] : []),
        ...messages
      ],
      stream: true
    }),
  });

  if (!upstream.ok || !upstream.body) {
    const text = await upstream.text().catch(() => "");
    return new Response("Upstream error: " + text, { status: 502, headers: cors(origin) });
  }

  // Pipe SSE stream to client
  const headers = {
    ...cors(origin),
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    "X-Accel-Buffering": "no",
  };

  return new Response(upstream.body, { status: 200, headers });
}
