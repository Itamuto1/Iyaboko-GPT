# Iyaboko GPT Proxy (Vercel Edge) — Iyaboko.org preconfigured

This proxy is pre-configured to allow CORS from:
- https://www.iyaboko.org
- https://iyaboko.org

It forwards browser requests to OpenAI's **Responses API** with **SSE streaming** so your API key remains server-side.

## Environment Variables (Vercel → Settings → Environment Variables)

Required:
- `OPENAI_API_KEY` — your OpenAI key

Optional (for rate limiting via Upstash Redis):
- `UPSTASH_REDIS_REST_URL`
- `UPSTASH_REDIS_REST_TOKEN`

If Upstash vars are set, the proxy enforces a **60 requests / 5 minutes / IP** limit. Without them, only a very light in-memory guard is used (not production-strong).

## Deploy Steps

1. Download & unzip.
2. Push to GitHub or import in Vercel.
3. Set env vars above.
4. Deploy. Your endpoint:
   `https://<your-vercel-project>.vercel.app/api/chat`

## Squarespace Embed (drop-in)

Replace `PROXY_URL` with your endpoint.

```html
<div id="iyaboko-gpt" style="max-width:720px;margin:1.5rem auto;padding:1rem;border:1px solid #333;border-radius:12px;background:#0b0b10;color:#e6e6e6;font-family:'Segoe UI',Arial,sans-serif;">
  <h3 style="margin-top:0;color:#d4af37;">Iyaboko Totaphysics GPT</h3>
  <div style="font-size:0.9rem;margin-bottom:0.5rem;opacity:0.9;">
    Ask anything about Totaphysics and the Reforming Universe.
  </div>
  <div id="chat" style="height:320px;overflow:auto;padding:0.75rem;border:1px solid #222;border-radius:10px;background:#0f1116;"></div>
  <textarea id="prompt" rows="3" placeholder="Type your question…" style="width:100%;margin-top:0.75rem;padding:0.75rem;border-radius:10px;border:1px solid #222;background:#0f1116;color:#e6e6e6;"></textarea>
  <div style="display:flex;gap:0.5rem;margin-top:0.5rem;">
    <button id="sendBtn" style="flex:1;padding:0.6rem 0.9rem;border:0;border-radius:10px;background:#d4af37;color:#000;font-weight:600;cursor:pointer;">Send</button>
    <button id="clearBtn" style="padding:0.6rem 0.9rem;border:1px solid #444;border-radius:10px;background:#12151c;color:#bbb;cursor:pointer;">Clear</button>
  </div>
</div>

<script>
(function(){
  const PROXY_URL = "https://<your-vercel-project>.vercel.app/api/chat"; // <-- change me
  const chat = document.getElementById('chat');
  const promptEl = document.getElementById('prompt');
  const sendBtn = document.getElementById('sendBtn');
  const clearBtn = document.getElementById('clearBtn');

  const system = "You are Totaphysics GPT. Follow Totaphysical logic (no multiverse, no divine/free will). Be concise, respectful, and accurate to Iyaboko doctrine.";

  function append(role, text) {
    const wrap = document.createElement('div');
    wrap.style.margin = '0.5rem 0';
    const bubble = document.createElement('div');
    bubble.style.whiteSpace = 'pre-wrap';
    bubble.style.padding = '0.6rem 0.8rem';
    bubble.style.borderRadius = '10px';
    bubble.style.border = '1px solid #222';
    bubble.style.background = role === 'user' ? '#12151c' : '#0c0f14';
    bubble.innerText = text;
    wrap.appendChild(bubble);
    chat.appendChild(wrap);
    chat.scrollTop = chat.scrollHeight;
  }

  async function send() {
    const text = promptEl.value.trim();
    if (!text) return;
    append('user', text);
    promptEl.value = '';

    const assistantWrap = document.createElement('div');
    assistantWrap.style.margin = '0.5rem 0';
    const assistantBubble = document.createElement('div');
    assistantBubble.style.whiteSpace = 'pre-wrap';
    assistantBubble.style.padding = '0.6rem 0.8rem';
    assistantBubble.style.borderRadius = '10px';
    assistantBubble.style.border = '1px solid #222';
    assistantBubble.style.background = '#0c0f14';
    assistantBubble.textContent = '';
    assistantWrap.appendChild(assistantBubble);
    chat.appendChild(assistantWrap);
    chat.scrollTop = chat.scrollHeight;

    const res = await fetch(PROXY_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        system,
        messages: [{ role: "user", content: text }]
      })
    });

    if (!res.ok) {
      assistantBubble.textContent = "Error: " + (await res.text());
      return;
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder("utf-8");
    let buffer = "";

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const parts = buffer.split("\n\n");
      buffer = parts.pop() || "";
      for (const part of parts) {
        if (!part.startsWith("data:")) continue;
        const payload = part.slice(5).trim();
        if (payload === "[DONE]") continue;
        try {
          const data = JSON.parse(payload);
          if (data.output_text !== undefined) {
            assistantBubble.textContent += data.output_text;
          } else if (Array.isArray(data.output)) {
            for (const item of data.output) {
              if (item.type === "message" && item.content?.length) {
                for (const c of item.content) {
                  if (c.type === "output_text" && c.text) {
                    assistantBubble.textContent += c.text;
                  }
                }
              } else if (item.type === "output_text" && item.text) {
                assistantBubble.textContent += item.text;
              }
            }
          }
          chat.scrollTop = chat.scrollHeight;
        } catch {}
      }
    }
  }

  sendBtn.addEventListener('click', send);
  promptEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) send();
  });
  clearBtn.addEventListener('click', () => { chat.innerHTML = ''; });
})();
</script>
```

## Notes
- This keeps your OpenAI key **server-side**.
- CORS is locked to `iyaboko.org` domains by default. Add preview domains if needed.
- If you enable Upstash variables, you'll get a proper IP rate limiter.
